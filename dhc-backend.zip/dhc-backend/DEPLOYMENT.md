# Check before deployment

- DHC_FRONTEND_BASE_URI is set correctly in server/settings.py?

# Deployment

Upload to remote from your local computer and in your backend project:
```bash
# ignore files starting with a dot
scp -r [!.]* root@135.181.165.62:/home/user/dhc/backend
```

Ensure to change owner on remote machine to 'user':
```bash
chown -R user:user /home/user/dhc/backend
```

Go to backend, change to user and activate environment::
```bash
su user
conda activate dhc-backend
```

Update dependencies and migrate database if needed:
```bash
pip install -r requirements.txt
python manage.py migrate
```

Optinally, restart backend as root if migration executed successfully:
```bash
systemctl restart dhc-backend-service
```