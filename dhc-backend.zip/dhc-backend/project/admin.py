
from django.contrib import admin
from .models import (
  AIParticipant,
  User, UserProfile, Participant, SpeechToTextMessage,
  Room
)

# Register your models here.
admin.site.register(AIParticipant)
admin.site.register(User)
admin.site.register(UserProfile)
admin.site.register(Participant)
admin.site.register(SpeechToTextMessage)
admin.site.register(Room)
