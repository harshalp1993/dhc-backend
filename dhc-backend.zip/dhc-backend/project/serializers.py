
from rest_framework import serializers
from rest_framework.authtoken.models import Token
from django.contrib.auth import get_user_model, password_validation
from django.contrib.auth.models import Group, AnonymousUser

from .managers import UserManager
from .models import (
    User,
    UserProfile,
    Room,
    Participant
)

User = get_user_model()


class GroupSerializer(serializers.ModelSerializer):
    """Group Serializer"""
    class Meta:
        model = Group
        fields = ('name',)


class UserProfileSerializer(serializers.ModelSerializer):
    """User Profile Serializer"""
    class Meta:
        model = UserProfile
        exclude = ('user', 'id',)

class UserSerializer(serializers.ModelSerializer):
    """User Serializer"""
    # associatons
    groups = GroupSerializer(many=True)
    profile = UserProfileSerializer(many=False)

    class Meta:
        model = get_user_model()
        fields = ('id', 'groups', 'profile', 'date_joined', 'email',)


class ParticipantSerializer(serializers.ModelSerializer):
    """Participant Serializer"""
    # associations
    user = UserSerializer(many=False, read_only=True)

    class Meta:
        model = Participant
        exclude = ('id',)

    # current user bounded token (taken from extra context)
    is_me = serializers.SerializerMethodField('is_context_user_me')

    def is_context_user_me(self, obj):
        user = self.context.get("user")
        if user is not None and user is not AnonymousUser:
            if obj.user is not None:
                if user.id == obj.user.id:
                    return True
        return False


class RoomCreateSerializer(serializers.Serializer):
    """Authorized users (doctor, admins, etc.) should be allowed 
    to create rooms. A payload is required for this, which contains
    all detailed information such as name, UUID, etc."""
    pass
    # uuid = serializers.CharField(max_length=300, required=True)

    # def validate_uuid(self, value):
    #     # TODO: only validate room uuid formally
    #     return value

class RoomUpdateSerializer(serializers.Serializer):
    """Updating a room is limited to a few fields"""
    pass

class RoomJoinSerializer(serializers.Serializer):
    """Normally a user needs at least one password or 
    token to be able to participate in an existing session."""
    pass
    # token = serializers.CharField(max_length=300, required=True)

    # def validate_token(self, value):
    #    valid_token_format = True
    #    # TODO: only validate token / password formally
    #    if not valid_token_format:
    #        raise serializers.ValidationError("token format does not correspond to the expected format")
    #    return value

class RoomLeaveSerializer(serializers.Serializer):
    """If payload data is required, this can be defined here"""
    pass

class RoomAddTextSerializer(serializers.Serializer):
    """If payload data is required, this can be defined here"""
    participant_uuid = serializers.CharField(required=True)
    text = serializers.CharField(required=False, allow_blank=True)
    partial = serializers.CharField(required=False, allow_blank=True)
    sequence_number = serializers.IntegerField(required=True)


class RoomAISerializer(serializers.Serializer):
    """If payload data is required, this can be defined here"""
    activate = serializers.BooleanField()

class RoomSerializer(serializers.ModelSerializer):
    # associations
    creator = UserSerializer(many=False, read_only=True)
    participants = ParticipantSerializer(many=True, read_only=True)

    # TODO: find out if this is still required in frontend
    # current user bounded token (taken from extra context)
    user_token = serializers.SerializerMethodField('get_user_token')

    class Meta:
        model = Room
        exclude = ('id', 'password')

    def get_user_token(self, obj):
        user = self.context.get("user")
        if user is not None and user is not AnonymousUser:
            participant = None
            try:
                participant = obj.participants.filter(user=user.id).first()
            except User.DoesNotExist:
                return None
            if participant is not None:
                return participant.uuid
        return None

"""
AUTHENTICATION
"""


class EmptySerializer(serializers.Serializer):
    pass


class LoginSerializer(serializers.Serializer):
    email = serializers.CharField(max_length=300, required=True)
    password = serializers.CharField(required=True)


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'password']

    def validate_email(self, value):
        user = User.objects.filter(email=value)
        if user:
            raise serializers.ValidationError("email is already taken")
        return UserManager.normalize_email(value)


class PasswordChangeSerializer(serializers.Serializer):
    current_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate_current_password(self, value):
        if not self.context['request'].user.check_password(value):
            raise serializers.ValidationError('Current password does not match')
        return value

    def validate_new_password(self, value):
        password_validation.validate_password(value)
        return value


class PasswordResetSerializer(serializers.Serializer):
    email = serializers.EmailField(required=True)


class PasswordResetConfirmSerializer(serializers.Serializer):
    new_password = serializers.CharField(required=True)
    token = serializers.CharField(required=True)

    def validate_new_password(self, value):
        password_validation.validate_password(value)
        return value


class TokenSerializer(serializers.ModelSerializer):
    token = serializers.SerializerMethodField()

    class Meta:
        model = get_user_model()
        fields = ('token',)

    def get_token(self, obj):
        token = Token.objects.get(user=obj)
        if token is not None:
            return token.key
        else:
            return ''


