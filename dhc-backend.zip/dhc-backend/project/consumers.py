import json
from urllib.parse import parse_qs

from django.contrib.auth.models import Group, AnonymousUser

from channels.db import database_sync_to_async
from asgiref.sync import sync_to_async

from channels.auth import get_user, login, logout
from channels.generic.websocket import AsyncWebsocketConsumer

from . import services


def get_header(key=None, headers=None):
    if headers is not None:
        for k, v in headers:
            if k == key:
                return v
    return None


GROUP_MESSAGE_TYPE = 'group.message'

class RoomConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        #print('::ws::connect')
        # retrieve scope information
        room_uuid = self.scope['url_route']['kwargs']['room_uuid']

        # extract room token and retrieve corresponding user
        query_string = self.scope['query_string']
        query_params = parse_qs(query_string.decode())

        # token to identify user is required and must be passed as query param
        token = None
        if 'token' in query_params:
            token = query_params['token'][0]
        if token is None or len(token) < 1:
            await self.close()

        # retrieve room
        self.room = await database_sync_to_async(
            services.get_room_by_uuid
        )(room_uuid)

        # retrieve user
        self.user = await database_sync_to_async(
            services.get_user_by_token
        )(token)

        # reject if room or user not found
        if self.room is None or self.user is None:
            await self.close()

        # add user as participant
        await database_sync_to_async(
            services.add_user_to_room
        )(self.user, self.room)

        # group name is room uuid
        self.group_name = self.room.uuid

        # add yourself to group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name,
        )

        # accept connection
        await self.accept()

        # notify connected clients
        message = {
            'type': GROUP_MESSAGE_TYPE,
            'event': 'connected',
            'sender': self.user.email,
            'message': 'user {} has joined room'.format(self.user.email)
        }
        await self.channel_layer.group_send(self.group_name, message)

    async def disconnect(self, close_code):
        #print('::ws::disconnect - user {} has left room'.format(self.user.email))

        # notify connected clients
        message = {
            'type': GROUP_MESSAGE_TYPE,
            'event': 'disconnected',
            'sender': self.user.email,
            'message': 'user {} has left room'.format(self.user.email)
        }
        await self.channel_layer.group_send(self.group_name, message)

        # remove as participant
        if self.user is not None and self.room is not None:
            await database_sync_to_async(
                services.remove_user_from_room
            )(self.user, self.room)
        
        # Leave room group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

        # reset
        self.user = None
        self.room = None


    async def receive(self, text_data=None, bytes_data=None):
        """Backend receives message from WebSocket user. 
        Dependig on use case this message can be braodcasted
        or not"""
        print('::receive {}'.format(self.user.email))
        text_data_json = json.loads(text_data)
        # message = text_data_json['message']
        # formatted_message = message['text']
        message = text_data_json
        # Broadcast message to room group
        # formatted_message = json.loads(message)['text']
        message = {
            'type': GROUP_MESSAGE_TYPE,
            'event': 'message',
            'sender': self.user.email,
            'message': message
        }
        await self.channel_layer.group_send(self.group_name, message)

    # must be in sync with GROUP_MESSAGE_TYPE (except dot)
    async def group_message(self, event):
        """Receive message from room group"""
        print('::group_message {}'.format(event))
        ev = event['event']
        sender = event['sender']

        #In this section, texts are processed according to the event type.
        if  ev in ["connected", "disconnected", "room_update"]:
            message = event['message']
            # Send message to WebSocket
            await self.send(text_data=json.dumps({
                'event': ev,
                'sender': sender,
                'message': message
            }))

        # Handle with chat messages
        elif ev == "message":
            message = event['message']
            # Send message to WebSocket
            await self.send(text_data=json.dumps({
                'event': ev,
                'sender': sender,
                'message': message
            }))

        # Handle with speech to text messages
        elif ev == "new_text":
            sequence_number = event['sequence_number']
            message = event['message']
            # Send message to WebSocket
            await self.send(text_data=json.dumps({
                'event': ev,
                'sender': sender,
                'sequence_number': sequence_number,
                'message': message
            }))


class AIConsumer(AsyncWebsocketConsumer):
    """AIConsumer used by ai participant INSTANCES (docker or bare metal)
    Not to be confused by the ai participant USER within DHC Backend. This
    user only authenticate an ai participant INSTANCE. An ai participant 
    INSTANCE will be added to DHC Backend on a successful WebSocket connection.
    That means the more instances we want, the more instances we can simply
    connect to this endpoint"""

    async def connect(self):
        print('::AIConsumer::connect')

        # extract query params
        query_string = self.scope['query_string']
        query_params = parse_qs(query_string.decode())

        # authorize this ai participant
        ai_participant_auth_token = None
        if 'ai_participant_auth_token' in query_params:
            ai_participant_auth_token = query_params['ai_participant_auth_token'][0]
        if ai_participant_auth_token is None or len(ai_participant_auth_token) < 1:
            await self.close()
        
        # TODO: check ai_participant_auth_token in db (ignored for now)

        # token to identify user is required and must be passed as query param
        ai_participant_uuid = None
        if 'ai_participant_uuid' in query_params:
            ai_participant_uuid = query_params['ai_participant_uuid'][0]
        if ai_participant_uuid is None or len(ai_participant_uuid) < 1:
            await self.close()

        # add this ai participant to database
        await database_sync_to_async(
            services.add_ai_participant_instance_to_db
        )(uuid=ai_participant_uuid)

        # group name is single instanced: ai_participant_uuid
        self.group_name = ai_participant_uuid

        # add yourself to group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name,
        )

        # accept connection
        await self.accept()

        # get user 'ai', retrieve auth token and return to instance
        auth_token = await database_sync_to_async(
            services.get_auth_token_key_of_first_user_by_group_name
        )(group_name='ai')

        # Send message back to ai participant instance
        await self.send(text_data=json.dumps({
            'event': 'on_connected',
            'auth_token': auth_token,
            'message': 'Successfully connected to DHC Backend. Please use the provided auth_token to exchange messages.'
        }))

    async def disconnect(self, close_code):
        print('::AIConsumer::disconnect')

        ai_participant_uuid = self.group_name

        # remove ai participant from database
        await database_sync_to_async(
            services.remove_ai_participant_instance_to_db
        )(uuid=ai_participant_uuid)

        # Leave room group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    async def group_message(self, event):
        print('::AIConsumer::group_message')
        
        ev = None
        uri = None
        room_uuid = None
        auth_token = None
        room_password = None
        message = None

        if 'event' in event:
            ev = event['event']
        if 'uri' in event:
            uri = event['uri']
        if 'room_uuid' in event:
            room_uuid = event['room_uuid']
        if 'auth_token' in event:
            auth_token = event['auth_token']
        if 'room_password' in event:
            room_password = event['room_password']
        if 'message' in event:
            message = event['message']

        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'event': ev,
            'uri': uri,
            'room_uuid': room_uuid,
            'auth_token': auth_token,
            'room_password': room_password,
            'message': message
        }))