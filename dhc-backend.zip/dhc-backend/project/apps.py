import sys
from django.apps import AppConfig

class ProjectConfig(AppConfig):
    name = 'project'


    def ready(self):
        """Override this method in subclasses to run code when Django starts."""
        # remove all ai participants from database.
        # Those instances should reconnect through websockets automatically
        if 'runserver' not in sys.argv:
            return True
        from project.models import AIParticipant
        AIParticipant.objects.all().delete()