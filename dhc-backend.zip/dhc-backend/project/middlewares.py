from channels.auth import AuthMiddlewareStack
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import AnonymousUser
from channels.db import database_sync_to_async

@database_sync_to_async
def get_token(key):
    try:
        return Token.objects.get(key=key)
    except Token.DoesNotExist:
        return None

@database_sync_to_async
def get_user_from_token(token):
    if token is not None:
        if token.user is not None:
            return token.user
    return AnonymousUser

class TokenAuthMiddleware:
    """
    Token authorization middleware for Django Channels
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        headers = dict(scope['headers'])
        if b'authorization' in headers:
            try:
                token_name, token_key = headers[b'authorization'].decode().split()
                if token_name == 'Token':
                    token = await get_token(key=token_key)
                    scope['user'] = await get_user_from_token(token=token)
            except Token.DoesNotExist:
                scope['user'] = None
        return await self.app(scope, receive, send)

TokenAuthMiddlewareStack = lambda inner: TokenAuthMiddleware(AuthMiddlewareStack(inner))