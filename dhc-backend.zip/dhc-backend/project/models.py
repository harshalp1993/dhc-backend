
from django.contrib.auth.models import AbstractUser, Group
from django.db import models
from django.utils.translation import gettext_lazy as _

from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token

from .managers import UserManager

class User(AbstractUser):
    objects = UserManager()

    # remove username
    username_validator = None
    username = None

    # make email unique
    email = models.EmailField(_('email address'), unique=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return "{}".format(self.email)

    @property
    def profile(self):
        return self.user_profile_set.first()


class UserProfile(models.Model):
    """The User Profile Model."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True, related_name='user_profile_set')
    prename = models.CharField(max_length=100, blank=True)
    surname = models.CharField(max_length=100, blank=True)
    title = models.CharField(max_length=100, blank=True)
    profession = models.CharField(max_length=100, blank=True)
    location = models.CharField(max_length=100, blank=True)
    avatar = models.TextField(blank=True)

    @property
    def name(self):
        return "{} {}".format(self.prename, self.surname)

    def __str__(self):
        user_name = self.user.email if self.user is not None else ''
        if len(user_name) > 0:
            return "{} ({})".format(self.name, user_name)
        return "{}".format(self.name)

class Participant(models.Model):
    """The Participant Model."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='owners')
    uuid = models.CharField(max_length=160, unique=True, blank=False)

    # track user is already in jitsi or only in the pre-join room page (lobby)
    state = models.CharField(max_length=160, default='lobby')

    # todo: user models
    messages_speech_to_text = models.TextField(default="")

    def __str__(self):
        return '{} ({})'.format(self.uuid, len(self.messages_speech_to_text))

class SpeechToTextMessage(models.Model):
    """Speech to Text messages recognized for specific participant"""
    participant = models.ForeignKey(Participant, on_delete=models.CASCADE, related_name='speech_to_text_messages')

    sequence_number = models.IntegerField(default=0)
    message = models.TextField()

    # meta
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '[{}] {} - {}'.format(self.participant, self.sequence_number, self.message)

class Room(models.Model):
    uuid = models.CharField(max_length=160, unique=True, blank=False)
    name = models.CharField(max_length=160, blank=False)
    password = models.CharField(max_length=160, blank=False)

    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='creators')
    participants = models.ManyToManyField(Participant)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '{} ({}, {})'.format(self.uuid, self.creator, self.participants.count())

class AIParticipant(models.Model):
    """The AIParticipant Model."""
    uuid = models.CharField(max_length=160, unique=True, blank=False)
    ref = models.CharField(max_length=160, unique=False, blank=False)
    state = models.CharField(max_length=160)

    # associations
    rooms = models.ManyToManyField(Room)
    
    # meta
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '{} ({})'.format(self.uuid, self.rooms.count())


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_auth_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)


# Signal on post save user will create user_profile automatically
@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_user_profile(sender, instance=None, created=False, **kwargs):
    if created:
        user_profile = UserProfile(user=instance)
        user_profile.save()
