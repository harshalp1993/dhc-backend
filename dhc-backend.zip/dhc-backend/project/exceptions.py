from rest_framework.exceptions import APIException
from rest_framework.views import exception_handler as drf_exception_handler

def exception_handler(exc, context):
    # Call REST framework's default exception handler first,
    # to get the standard error response.
    response = drf_exception_handler(exc, context)
    if isinstance(exc, APIException):
        if response is not None:
            response.data = {'error': exc.detail}

    return response