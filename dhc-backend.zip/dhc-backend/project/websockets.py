# routing.py

import os

from channels.routing import URLRouter
from django.conf.urls import url

from project.middlewares import TokenAuthMiddlewareStack
from project.consumers import RoomConsumer, AIConsumer


websocket_urlpatterns = [
    url(r"^ws/rooms/(?P<room_uuid>[^/]+)/$", RoomConsumer.as_asgi()),
    url(r"^ws_ai/$", AIConsumer.as_asgi()),
]

def get_websocket_application():
    return TokenAuthMiddlewareStack(
        URLRouter(websocket_urlpatterns)
    )
