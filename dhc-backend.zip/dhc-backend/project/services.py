import uuid

from rest_framework import serializers
from rest_framework.authtoken.models import Token

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode


from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync


from .models import Room, Participant, AIParticipant, User

def get_and_authenticate_user(email, password):
    user = authenticate(username=email, password=password)
    if user is None:
        raise serializers.ValidationError("Invalid username/password. Please try again!")
    # ensure to have a valid token
    Token.objects.get_or_create(user=user)
    return user


def create_user_account(email, password, first_name="", last_name="", **extra_fields):
    user = get_user_model().objects.create_user(
        email=email,
        password=password,
        first_name=first_name,
        last_name=last_name,
        **extra_fields
    )
    return user


def get_user_by_email(email):
    return get_user_model().objects.filter(email__iexact=email).first()


def get_token_for_password_reset(user):
    user_pk = urlsafe_base64_encode(force_bytes(user.pk))
    reset_token = PasswordResetTokenGenerator().make_token(user)
    return "{}::{}".format(user_pk, reset_token)


def send_password_reset_mail(user):
    token = get_token_for_password_reset(user)
    print('TODO: SENT EMAIL TO USER WITH CONFIRMTATION CODE: {}'.format(token))
    return ''


def get_user_for_password_reset_token(token):
    invalid_token = 'invalid token or the token has expired'
    user_not_found = 'no user exists for given token'

    try:
        user_pk, reset_token = token.split("::")
    except ValueError:
        raise serializers.ValidationError(invalid_token)

    try:
        user_id = force_text(urlsafe_base64_decode(user_pk))
    except (ValueError, OverflowError, TypeError):
        raise serializers.ValidationError(invalid_token)

    if not user_id:
        raise serializers.ValidationError(invalid_token)

    user = get_user_model().objects.filter(id=user_id).first()

    if not user:
        raise serializers.ValidationError(user_not_found)

    if not PasswordResetTokenGenerator().check_token(user, reset_token):
        raise serializers.ValidationError(invalid_token)

    return user


"""
"""

def create_room(user, **extra_fields):
    """HTTP user wants to create new room. Restrict to only users and
    users belonging to group 'doctor'."""
    if user is None:
        raise Exception('user is None')
    allowed = user.is_staff or user.groups.filter(name='doctor').exists()
    if not allowed:
        raise Exception('user must be either staff member or in group doctor')

    return Room.objects.create(
        creator=user,
        uuid=uuid.uuid4(),
        **extra_fields
    )


def join_room(room, user, password=None, **extra_fields):
    """HTTP user wants to join an existing room. It is also checked
    whether the room requires a token / password and whether the user
    is registered or anonymous. Temporary users are created in the 
    database for anonymous users."""
    if room is None:
        raise Exception('room is None')

    if user is None:
        raise Exception('user is None')

    if room.password is not None and len(room.password) > 0:
        if password is None or len(password) < 1:
            raise Exception('room password required to join')
        else:
            if room.password != password:
                raise Exception('room password does not match')

    if user.is_anonymous:
        raise Exception('anonymous joining is not allowed. First, create a user account.')

    # generate and add access token to room for websocket connections
    # those tokens will be appended as query_string in ws connect
    # to identify specific user (as headers are not available in ws)
    add_user_to_room(user=user, room=room)

def leave_room(room, user, **extra_fields):
    """HTTP - user wants to leave existing room"""
    if room is None:
        raise Exception('room is None')

    if user is None:
        raise Exception('user is None')

    if not is_user_in_room(user, room):
        raise Exception('user is not in room')

    room.participants.filter(user=user).delete()


def get_participant_by_uuid(room, uuid):
    try:
        return room.participants.filter(uuid=uuid).first()
    except User.DoesNotExist:
        return None
    return None


def update_ai_for_room(room, user, **extra_fields):
    """HTTP - doctor wants to enable (start) or disable (stop) ai participant for a specific room"""
    if room is None:
        raise Exception('room is None')
    if user is None:
        raise Exception('user is None')
    if not user.groups.filter(name="doctor").exists():
        raise Exception('user not a doctor')

    activate = extra_fields.get('activate', None)
    if activate:
        ai_participant_start_for_room(room=room)
    else:
        ai_participant_stop_for_room(room=room)


def add_text(room, user, **extra_fields):
    """HTTP - user wants to leave existing room"""
    if room is None:
        raise Exception('room is None')
    if user is None:
        raise Exception('user is None')

    # ensure participant exists and is in room
    participant_uuid = extra_fields.get('participant_uuid', None)
    participant = get_participant_by_uuid(room, participant_uuid)
    if participant is None:
        raise Exception('participant not found')

    # TODO:
    # sequence number for text identification 
    # => 'partial' with same sequence number will be replaced
    # => 'text' with same sequence number as 'partial' replaces content of 'partial' completely
    sequence_number = 0
    sequence_number_str = extra_fields.get('sequence_number', None)
    if sequence_number_str is not None:
        sequence_number = int(sequence_number_str)
    if sequence_number == 0:
        raise Exception('sequence number must be greater 0')

    # message results from either 'text' or 'partial'
    partial = extra_fields.get('partial', None)
    text = extra_fields.get('text', None)
    message = text if len(text) > 0 else partial

    # find and update or create new speech to text message for participant
    speech_to_text_message = participant.speech_to_text_messages.filter(sequence_number=sequence_number).first()
    if speech_to_text_message is None:
        participant.speech_to_text_messages.create(
            participant=participant,
            sequence_number=sequence_number,
            message=message,
        )
    else:
        speech_to_text_message.message = message
        speech_to_text_message.save()

    if participant is not None:
        participant.messages_speech_to_text = '{} {}'.format(participant.messages_speech_to_text, text)
    participant.save()
    
    # notify participants
    channel_layer = get_channel_layer()
    if channel_layer is not None:
        group_name = room.uuid
        GROUP_MESSAGE_TYPE = 'group.message'
        message = {
            'type': GROUP_MESSAGE_TYPE,
            'event': 'new_text',
            'sender': participant.user.email,
            'sequence_number': sequence_number,
            'message': '{}'.format(message)
        }
        print("sending to ws channel: {} and group: {}".format(channel_layer, group_name))
        async_to_sync(channel_layer.group_send)(group_name, message)


"""
WebSocket methods (room consumer)
"""
def get_auth_token_key_of_first_user_by_group_name(group_name=None):
    try:
        return get_user_model().objects.filter(groups__name=group_name).first().auth_token.key
    except get_user_model().DoesNotExist:
        return None

def get_room_by_uuid(room_uuid):
    return Room.objects.filter(uuid=room_uuid).first()

def is_user_in_room(user, room):
    if user is None or room is None:
        return False
    try:
        return room.participants.filter(user=user.id).exists()
    except Participant.DoesNotExist:
        pass
    return False

def get_user_by_token(key):
    user = Token.objects.get(key=key).user
    if user is not None:
        return user
    return None

def add_user_to_room(user, room):
    """ws - add existing user to existing room"""
    if not is_user_in_room(user, room):
        participant = Participant.objects.create(
            user=user,
            uuid=uuid.uuid4(),
        )
        room.participants.add(participant)


def remove_user_from_room(user, room):
    """ws - remove existing user from existing room"""
    if is_user_in_room(user, room):
        room.participants.filter(user=user).delete()


def notify_participants_to_fetch_latest_room_details(room_uuid=None):
    try:
        Room.objects.filter(uuid=room_uuid).first()
    except Room.DoesNotExist:
        return None

    # notify participants
    channel_layer = get_channel_layer()
    if channel_layer is not None:
        group_name = room_uuid
        message = {
            'type': 'group.message',
            'event': 'room_update',
            'sender': 'system',
            'message': 'please fetch the latest room details using Backend HTTP API server'
        }
        print("sending to ws channel: {} and group: {}".format(channel_layer, group_name))
        async_to_sync(channel_layer.group_send)(group_name, message)

"""
AI Participant Instance
"""


def add_ai_participant_instance_to_db(uuid):
    """add new ai participant instance to database ready for the next sessions"""
    print("::add_ai_participant_instance_to_db:{}".format(uuid))
    if uuid is None:
        return False

    if AIParticipant.objects.filter(uuid=uuid).exists():
        remove_ai_participant_instance_to_db(uuid=uuid)

    AIParticipant.objects.create(
        uuid=uuid,
        ref="todo",
    )


def remove_ai_participant_instance_to_db(uuid):
    """removes existing ai participant from database"""
    print("::remove_ai_participant_instance_to_db")
    if AIParticipant.objects.filter(uuid=uuid).exists():
        AIParticipant.objects.filter(uuid=uuid).delete()


def ai_participant_start_for_room(room):
    """Find the next free AI participant instance and create a new session in the database.
    This means that a websocket message is sent to the corresponding ai participant instance
    to notify the instance to connect to an existing Jitsi session"""
    print("::ai_participant_start_for_room")
    if room is None:
        raise Exception("room is not set")

    # get some details
    room_uuid = room.uuid

    # get internal AI USER (not instance!)
    ai_users = get_user_model().objects.filter(groups__name="ai")
    if ai_users.count() < 1:
        raise Exception("no ai user available. aborting")
    ai_user = ai_users.first()
    if ai_user.auth_token is None:
        raise Exception("ai user has no token. aborting")

    # get the auth token
    auth_token = ai_user.auth_token.key
    if auth_token is None or len(auth_token) < 1:
        raise Exception("auth token is invalid")

    # get the room password
    room_password = room.password

    # combine all information in one single uri (headers not allowed in ws)
    uri = '{}/{}/ai'.format(settings.DHC_FRONTEND_BASE_URI, room_uuid)

    # TODO: search for free ones only
    if AIParticipant.objects.count() < 1:
        raise Exception("no ai participant instances available")

    ai_participant = AIParticipant.objects.last()
    if ai_participant is not None:

        # update object
        ai_participant.rooms.add(room)

        # notifiy connected ai participant
        channel_layer = get_channel_layer()
        if channel_layer is not None:
            group_name = ai_participant.uuid
            message = {
                'type': 'group.message',
                'event': 'on_started',
                'uri': uri,
                'room_uuid': room_uuid,
                'auth_token': auth_token,
                'room_password': room_password,
                'message': 'Please create headless browser instance and connect to provided URI'
            }
            async_to_sync(channel_layer.group_send)(group_name, message)

def ai_participant_stop_for_room(room):
    """Find the responsible AI participant and remove the room from the object. Also let 
    the AI ​​participant know that he can move away from the room"""
    print("::ai_participant_stop_for_room")
    if room is None:
        raise Exception("room is not set")

    # get room details
    room_uuid = room.uuid

    # get the corresponding ai participant
    ai_participant = AIParticipant.objects.filter(rooms__uuid=room_uuid).first()
    if ai_participant is None:
        raise Exception("could not find the corresponding ai participant for room with uuid: {}".format(room_uuid))

    # update object
    ai_participant.rooms.remove(room)

    # notifiy connected ai participant
    channel_layer = get_channel_layer()
    if channel_layer is not None:
        group_name = ai_participant.uuid
        uri = '{}/{}'.format(settings.DHC_FRONTEND_BASE_URI, room_uuid)
        message = {
            'type': 'group.message',
            'event': 'on_stopped',
            'room_uuid': room_uuid,
            'message': 'Please destroy your headless browser instance and wait for further instructions'
        }
        async_to_sync(channel_layer.group_send)(group_name, message)