from django.test import TestCase
from django.urls import reverse

from project.models import User, UserProfile

import random
import sys

class AuthRegisterViewTests(TestCase):

    def test_invalid(self):
        payload = None
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {}
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "unknown": "value"
        }
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "wrong"
        }
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "right@domain.io"
        }
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "right@domain.io",
            "password": ""
        }
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertNotEqual(response.status_code, 200)


    def test_single(self):
        payload = {
            "email": "001@tld.com",
            "password": "1234qwer",
		}
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertEqual(response.status_code, 201)


    def test_duplicate(self):
        payload = {
            "email": "001@tld.com",
            "password": "1234qwer",
		}
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertEqual(response.status_code, 201)

        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertEqual(response.status_code, 400)

    def test_ensure_user_profile_created_and_deleted_automatically(self):
        payload = {
            "email": "001@tld.com",
            "password": "1234qwer",
		}
        response = self.client.post(reverse("auth-register"), data=payload)
        self.assertEqual(response.status_code, 201)

        # user_profile created
        user = User.objects.filter(email=payload["email"]).first()
        if user is None:
            self.fail("user_profile was not created")        
        self.assertTrue(user.profile is not None)
        self.assertTrue(user.profile.pk > 0)

        # user_profile deleted
        self.assertEqual(User.objects.count(), 1)
        self.assertEqual(UserProfile.objects.count(), 1)
        user.delete()
        self.assertEqual(User.objects.count(), 0)
        self.assertEqual(UserProfile.objects.count(), 0)

