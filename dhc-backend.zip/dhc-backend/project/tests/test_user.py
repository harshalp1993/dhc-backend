from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

from rest_framework.test import APIClient

import json
import random
import sys
from project.models import User, Token

class UserViewTests(TestCase):

    def setUp(self):
        User = get_user_model()
        self.u1 = User.objects.create_user(email="u1@domain.io", password="password1")
        self.u2 = User.objects.create_user(email="u2@domain.io", password="password1")
        self.u_admin = User.objects.create_superuser(email="super@domain.io", password="password1")

        t1 = Token.objects.get(user=self.u1)
        self.client = APIClient()
        self.client.credentials(HTTP_AUTHORIZATION="Token {}".format(t1))

        t2 = Token.objects.get(user=self.u_admin)
        self.client_admin = APIClient()
        self.client_admin.credentials(HTTP_AUTHORIZATION="Token {}".format(t2))


    def test_list_disallow(self):
        response = self.client.get(reverse("user-list"), data=None)
        self.assertNotEqual(response.status_code, 200)


    def test_list_allow(self):
        response = self.client_admin.get(reverse("user-list"), data=None)
        self.assertEqual(response.status_code, 200)


    def test_get_disallow(self):
        path = reverse("user-detail", kwargs={"pk": self.u2.pk})
        response = self.client.get(path, data=None)
        self.assertNotEqual(response.status_code, 200)

        path = reverse("user-detail", kwargs={"pk": self.u_admin.pk})
        response = self.client.get(path, data=None)
        self.assertNotEqual(response.status_code, 200)


    def test_get_allow(self):
        path = reverse("user-detail", kwargs={"pk": self.u1.pk})
        response = self.client.get(path, data=None)
        self.assertEqual(response.status_code, 200)

        path = reverse("user-detail", kwargs={"pk": self.u1.pk})
        response = self.client_admin.get(path, data=None)
        self.assertEqual(response.status_code, 200)

        path = reverse("user-detail", kwargs={"pk": self.u_admin.pk})
        response = self.client_admin.get(path, data=None)
        self.assertEqual(response.status_code, 200)