from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

from rest_framework.test import APIClient

import json
import random
import sys
from project.models import Group, User, Token, Room

class RoomViewTests(TestCase):

    def setUp(self):
        # create users
        User = get_user_model()
        self.user_1 = User.objects.create_user(email="user1@domain.io", password="password1")
        self.user_2 = User.objects.create_user(email="user2@domain.io", password="password1")
        self.user_admin = User.objects.create_superuser(email="admin@domain.io", password="password1")
        self.user_doctor = User.objects.create_user(email="doctor@domain.io", password="password1")
        self.user_ai = User.objects.create_user(email="ai@domain.io", password="password1")

        # create gorups
        group_admin, _ = Group.objects.get_or_create(name='admin')
        group_doctor, _ = Group.objects.get_or_create(name='doctor')
        group_ai, _ = Group.objects.get_or_create(name='ai')

        # assign groups
        self.user_admin.groups.add(group_admin)
        self.user_doctor.groups.add(group_doctor)
        self.user_ai.groups.add(group_ai)

        # create clients for each user
        self.client_anonymous = APIClient()
        self.client_user_1 = APIClient()
        self.client_user_2 = APIClient()
        self.client_user_admin = APIClient()
        self.client_user_doctor = APIClient()
        self.client_user_ai = APIClient()

        # setup clients
        self.client_user_1.credentials(HTTP_AUTHORIZATION="Token {}".format(Token.objects.get(user=self.user_1)))
        self.client_user_2.credentials(HTTP_AUTHORIZATION="Token {}".format(Token.objects.get(user=self.user_2)))
        self.client_user_admin.credentials(HTTP_AUTHORIZATION="Token {}".format(Token.objects.get(user=self.user_admin)))
        self.client_user_doctor.credentials(HTTP_AUTHORIZATION="Token {}".format(Token.objects.get(user=self.user_doctor)))
        self.client_user_ai.credentials(HTTP_AUTHORIZATION="Token {}".format(Token.objects.get(user=self.user_ai)))

        # create rooms
        self.room_1, _ = Room.objects.get_or_create(uuid='room_uuid_1', creator=self.user_doctor)


    def test_list_get_disallowed(self):
        """anonymous user should not be allowed to list rooms"""
        rooms_list = reverse("room-list")
        self.assertNotEqual(self.client_anonymous.get(rooms_list, data=None).status_code, 200)


    def test_list_get_allowed(self):
        """registered user should be allowed to list rooms"""
        rooms_list = reverse("room-list")
        self.assertEqual(self.client_user_1.get(rooms_list, data=None).status_code, 200)
        self.assertEqual(self.client_user_admin.get(rooms_list, data=None).status_code, 200)
        self.assertEqual(self.client_user_doctor.get(rooms_list, data=None).status_code, 200)
        self.assertEqual(self.client_user_ai.get(rooms_list, data=None).status_code, 200)


    def test_list_post_disallowed(self):
        """anonymous user should not be allowed to create new rooms"""
        rooms_list = reverse("room-list")
        self.assertNotEqual(self.client_anonymous.post(rooms_list, data=None).status_code, 201)
        self.assertNotEqual(self.client_user_1.post(rooms_list, data=None).status_code, 201)
        self.assertNotEqual(self.client_user_ai.post(rooms_list, data=None).status_code, 201)


    def test_list_post_allowed(self):
        """registered user (staff or doctor only) should be allowed to create rooms"""
        rooms_list = reverse("room-list")
        self.assertEqual(self.client_user_admin.post(rooms_list, data=None).status_code, 201)
        self.assertEqual(self.client_user_doctor.post(rooms_list, data=None).status_code, 201)


    def test_detail_get_disallowed(self):
        """get room details should not be disallowed"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        self.assertTrue(True)

    def test_detail_get_allowed(self):
        """anonymous and registered user should be allowed to retrieve room details"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        self.assertEqual(self.client_anonymous.get(rooms_detail, data=None).status_code, 200)
        self.assertEqual(self.client_user_1.get(rooms_detail, data=None).status_code, 200)
        self.assertEqual(self.client_user_admin.get(rooms_detail, data=None).status_code, 200)
        self.assertEqual(self.client_user_doctor.get(rooms_detail, data=None).status_code, 200)
        self.assertEqual(self.client_user_ai.get(rooms_detail, data=None).status_code, 200)



    def test_detail_delete_disallowed(self):
        """anonymous and non creator users should not be allowed to delete existing room"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        self.assertNotEqual(self.client_anonymous.delete(rooms_detail, data=None).status_code, 204)
        self.assertNotEqual(self.client_user_1.delete(rooms_detail, data=None).status_code, 204)
        self.assertNotEqual(self.client_user_ai.delete(rooms_detail, data=None).status_code, 204)



    def test_detail_delete_allowed_for_creator(self):
        """registered user (creator only) should be allowed to delete existing room"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        self.assertEqual(self.client_user_doctor.delete(rooms_detail, data=None).status_code, 204)
    
    def test_detail_delete_allowed_for_staff(self):
        """registered user (staff only) should be allowed to delete existing room"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        self.assertEqual(self.client_user_admin.delete(rooms_detail, data=None).status_code, 204)

    def test_detail_update_disallowed(self):
        """anonymous and non creator users should not be allowed to delete existing room"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        self.assertNotEqual(self.client_anonymous.patch(rooms_detail, data=None).status_code, 200)
        self.assertNotEqual(self.client_user_1.patch(rooms_detail, data=None).status_code, 200)
        self.assertNotEqual(self.client_user_ai.patch(rooms_detail, data=None).status_code, 200)
    
    def test_detail_update_allowed_for_creator(self):
        """registered user (creator only) should be allowed to delete existing room"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        data = {"password": "room1"}
        self.assertEqual(self.client_user_doctor.patch(rooms_detail, data=data).status_code, 200)
    
    def test_detail_update_allowed_for_staff(self):
        """registered user (staff only) should be allowed to delete existing room"""
        rooms_detail = reverse("room-detail", kwargs={"uuid": self.room_1.uuid})
        data = {"password": "room1"}
        self.assertEqual(self.client_user_admin.patch(rooms_detail, data=data).status_code, 200)
    
    # TODO: tests:
    # - who is allowed to update room detail? => staff or owner only
    # - who is allowed to delete rooms? => staff or owner only
    # - room with password
