from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient

import random
import sys
from project.models import User


class AuthTokenViewTests(TestCase):

    def setUp(self):
        User = get_user_model()
        User.objects.create_user(email="u1@domain.io", password="password1")


    def test_user_logout_login_new_token(self):
        payload = {
            "email": "u1@domain.io",
            "password": "password1",
		}

        # login -> create new token
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["token"] is not None)
        self.assertEqual(Token.objects.count(), 1)

        # update client
        self.client = APIClient()
        self.client.credentials(HTTP_AUTHORIZATION="Token {}".format(response.data["token"]))

        # logout -> remove token
        response = self.client.post(reverse("auth-logout"), data=payload)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Token.objects.count(), 0)

        # update client
        self.client = APIClient()

        # re-login -> re-create new token
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["token"] is not None)
        self.assertEqual(Token.objects.count(), 1)
