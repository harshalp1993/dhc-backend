from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

import random
import sys
from project.models import User

class AuthLoginViewTests(TestCase):

    def setUp(self):
        User = get_user_model()
        User.objects.create_user(email="u1@domain.io", password="password1")
        User.objects.create_user(email="u2@domain.io", password="password2")


    def test_invalid(self):
        payload = None
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {}
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "unknown": "value"
        }
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "wrong"
        }
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "u1@domain.io"
        }
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "u1@domain.io",
            "password": ""
        }
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)

        payload = {
            "email": "u1@domain.io",
            "password": "wrongpassword"
        }
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertNotEqual(response.status_code, 200)


    def test_single(self):
        payload = {
            "email": "u1@domain.io",
            "password": "password1",
		}
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data is not None)
        self.assertTrue(response.data["token"] is not None)
