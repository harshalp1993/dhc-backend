from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

from rest_framework.test import APIClient

import json
import random
import sys
from project.models import User, Token

class UserProfileViewTests(TestCase):

    def setUp(self):
        User = get_user_model()
        self.u1 = User.objects.create_user(email="u1@domain.io", password="password1")
        t1 = Token.objects.get(user=self.u1)

        # set some initial values
        p1 = self.u1.profile
        p1.title = "old_title"
        p1.save()

        self.client = APIClient()
        self.client.credentials(HTTP_AUTHORIZATION="Token {}".format(t1))


    def test_patch_single(self):
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "old_title")

        payload = json.dumps({
            "title": "new_title",
		})
        path = reverse("user-profiles-list", kwargs={"user_pk": self.u1.pk})
        response = self.client.patch(path, data=payload, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "new_title")


    def test_patch_multiple(self):
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "old_title")

        payload = json.dumps({
            "title": "new_title",
            "profession": "new_profession",
		})
        path = reverse("user-profiles-list", kwargs={"user_pk": self.u1.pk})
        response = self.client.patch(path, data=payload, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "new_title")
        self.assertEqual(p1.profession, "new_profession")


    def test_patch_reset(self):
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "old_title")

        payload = json.dumps({
            "title": "",
		})
        path = reverse("user-profiles-list", kwargs={"user_pk": self.u1.pk})
        response = self.client.patch(path, data=payload, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "")


    def test_patch_check_user(self):
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "old_title")

        payload = json.dumps({
            "title": "new_title",
		})
        path = reverse("user-profiles-list", kwargs={"user_pk": self.u1.pk})
        response = self.client.patch(path, data=payload, content_type="application/json")
        self.assertEqual(response.status_code, 200)
        
        p1 = User.objects.first().profile
        self.assertEqual(p1.title, "new_title")