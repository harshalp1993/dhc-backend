from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from channels.testing import WebsocketCommunicator
from project.websockets import get_websocket_application
from server.asgi import application
from project.models import Group, User, Token, Room, Participant
from asgiref.sync import sync_to_async
  
import pytest
from channels.testing import HttpCommunicator, WebsocketCommunicator
from channels.layers import get_channel_layer
from channels.db import database_sync_to_async
from django.db import transaction

TEST_CHANNEL_LAYERS = {
    "default": {"BACKEND": "channels.layers.InMemoryChannelLayer",},
}

@pytest.fixture(scope='function', autouse=True)
def create_user():
    with transaction.atomic():
        User.objects.all().delete()
        user = User.objects.create_user(email="doctor@domain.io", password="password1")
    return user

@pytest.fixture
def participant(create_user):
    participant, _ = Participant.objects.get_or_create(uuid="participant_uuid_1", user=create_user)
    return participant

@pytest.fixture
def room(create_user, participant):
    room, _ = Room.objects.get_or_create(uuid='room_uuid_1', creator=create_user)
    room.participants.add(participant)
    return room

@pytest.mark.django_db(transaction=True)
@pytest.mark.asyncio
class TestRoomConsumer:
    
    async def test_user_can_connect(self, room, create_user, settings):
        settings.CHANNEL_LAYERS = TEST_CHANNEL_LAYERS
        token = await sync_to_async(Token.objects.get)(user=create_user)
        headers = [(b'origin', b'...'), (b'authorization', f"Token {token}".encode())]
        communicator = WebsocketCommunicator(
            application=application, 
            path=f"/ws/rooms/{room.uuid}/?token={token}", 
            headers=headers
        )
        # print(communicator)
        connected, _ = await communicator.connect()
        # print(connected)
        assert connected
        await communicator.disconnect()
    
    async def test_can_send_and_receive_messages(self, room, create_user, settings):
        settings.CHANNEL_LAYERS = TEST_CHANNEL_LAYERS
        token = await sync_to_async(Token.objects.get)(user=create_user)
        headers = [(b'origin', b'...'), (b'authorization', f"Token {token}".encode())]
        communicator = WebsocketCommunicator(
            application=application, 
            path=f"/ws/rooms/{room.uuid}/?token={token}", 
            headers=headers
        )
        connected, _ = await communicator.connect()
        response1 = await communicator.receive_json_from()
        assert response1['message'] == f'user {create_user} has joined room'

        message = 'This is a test message.'
        await communicator.send_json_to(message)
        response2 = await communicator.receive_json_from()
        assert response2['message'] == message
        await communicator.disconnect()

