from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

from rest_framework.test import APIClient

import random
import sys
from project.models import User, Token

class AuthLoginViewTests(TestCase):

    def setUp(self):
        User = get_user_model()
        User.objects.create_user(email="u1@domain.io", password="password1")
        User.objects.create_user(email="u2@domain.io", password="password2")


    def test_logout(self):
        payload = {
            "email": "u1@domain.io",
            "password": "password1",
		}
        response = self.client.post(reverse("auth-login"), data=payload)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data is not None)
        self.assertTrue(response.data["token"] is not None)
        num_tokens = Token.objects.count()

        self.client = APIClient()
        self.client.credentials(HTTP_AUTHORIZATION="Token {}".format(response.data["token"]))
        response = self.client.post(reverse("auth-logout"), data=None)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data is not None)
        self.assertTrue(response.data["success"] is not None)
        self.assertEqual(num_tokens - 1, Token.objects.count())
