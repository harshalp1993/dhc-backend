import json
import uuid

from django.contrib.auth import get_user_model, logout
from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import Group
from django.core.exceptions import ImproperlyConfigured
from django.http import JsonResponse
from django.db.models import ObjectDoesNotExist

from rest_framework import viewsets, status, mixins
from rest_framework.decorators import action
from rest_framework.exceptions import APIException, NotFound
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination


from . import serializers, services, models


class DefaultPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'

class ActionBasedPermission(AllowAny):
    def has_permission(self, request, view):
        for klass, actions in getattr(view, 'action_permissions', {}).items():
            if view.action in ['create', 'update', 'partial_update', 'destroy']:
                # which is permissions.IsAdminUser or user's group is doctor
                return request.user.groups.filter(name='doctor').exists() or request.user.is_staff  
            elif view.action in ['list']:
                # which is permissions.IsAuthenticated
                return request.user.is_authenticated          
            else :
                # which is permissions.AllowAny
                return True
        return False

class RoomViewSet(
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
    viewsets.GenericViewSet):

    serializer_class = serializers.RoomSerializer
    pagination_class = DefaultPagination
    #permission_classes = [IsAuthenticated, ]
    permission_classes = (ActionBasedPermission,)
    action_permissions = {
        IsAuthenticated: ['create', 'update', 'partial_update', 'destroy', 'list'],
        AllowAny: ['retrieve']
    }

    queryset = models.Room.objects.all()
    lookup_field = 'uuid' # /rooms/{uuid}

    def create(self, request, *args, **kwargs):
        """creates new room"""
        serializer = serializers.RoomCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        created_room = None
        try:
            created_room = services.create_room(
                user=self.request.user,
                **serializer.validated_data
            )
        except Exception as e:
            data = {'error': 'could not create room. Error: {e}'.format(e=e)}
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)

        if created_room is not None:
            room_uuid = created_room.uuid
            queryset = models.Room.objects.filter(uuid__iexact=str(room_uuid)).first()
            extra_context = {'user': self.request.user}
            data = serializers.RoomSerializer(queryset, context=extra_context).data
            return Response(data=data, status=status.HTTP_201_CREATED)
        else:
            data = {'error': 'created room seems to be invalid'}
            return Response(data=data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def list(self, request, *args, **kwargs):
        """lists all rooms"""
        # user = self.request.user
        queryset = models.Room.objects.all()

        # get query params
        order_by = self.request.query_params.get('order_by', None)
        if order_by is not None:
            queryset = queryset.order_by(order_by)

        # queryset = models.Room.objects.filter(creator=user)
        queryset_page = self.paginate_queryset(queryset)
        extra_context = {'user': self.request.user}
        if queryset_page is not None:
            serializer = serializers.RoomSerializer(queryset_page, many=True, context=extra_context)
            return self.get_paginated_response(serializer.data)
        serializer = serializers.RoomSerializer(queryset, many=True, context=extra_context)
        return Response(serializer.data)

    def retrieve(self, request, *args, **kwargs):
        """retrieves details for specific room"""
        room_uuid = self.kwargs.get('uuid')
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        extra_context = {'request': self.request, 'user': self.request.user}
        serializer = serializers.RoomSerializer(queryset, many=False, context=extra_context)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        """updates specific room"""
        room_uuid = self.kwargs.get('uuid')
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        serializer = serializers.RoomUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return super().update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        """deletes specific room"""
        room_uuid = self.kwargs.get('uuid')
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(methods=['GET', ], detail=True, name='join existing room', permission_classes=[AllowAny], url_name='detail-join')
    def join(self, request, *args, **kwargs):
        """join as user to specific room"""
        serializer = serializers.RoomJoinSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        room_uuid = self.kwargs.get('uuid')
        room_password = self.request.query_params.get('password', None)
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        try:
            services.join_room(
                room=self.get_object(),
                user=self.request.user,
                password = room_password,
                **serializer.validated_data,
            )
        except Exception as e:
            data = {'error': 'could not join room. Error: {e}'.format(e=e)}
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)
        extra_context = {'user': self.request.user}
        data = serializers.RoomSerializer(self.get_object(), context=extra_context).data
        return Response(data=data, status=status.HTTP_200_OK)

    @action(methods=['GET', ], detail=True, name='leave existing room', permission_classes=[AllowAny], url_name='detail-leave')
    def leave(self, request, *args, **kwargs):
        """leave as user from specific room"""
        serializer = serializers.RoomLeaveSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        room_uuid = self.kwargs.get('uuid')
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        try:
            services.leave_room(
                room=self.get_object(),
                user=self.request.user,
                **serializer.validated_data,
            )
        except Exception as e:
            data = {'error': 'could not leave room. Error: {e}'.format(e=e)}
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)
        data = serializers.RoomSerializer(self.get_object()).data
        return Response(data=data, status=status.HTTP_200_OK)

    @action(methods=['POST', ], detail=True, name='adds new recognized text for provided participant', permission_classes=[AllowAny], url_name='detail-add-text')
    def add_text(self, request, *args, **kwargs):
        """adds new recognized text for provided participant"""
        serializer = serializers.RoomAddTextSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        room_uuid = self.kwargs.get('uuid')
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        try:
            services.add_text(
                room=self.get_object(),
                user=self.request.user,
                **serializer.validated_data,
            )
        except Exception as e:
            data = {'error': 'could not add new text to participant. Error: {e}'.format(e=e)}
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)
        return Response(data=None, status=status.HTTP_200_OK)

    @action(methods=['POST', ], detail=True, name='start or stop ai participant for a specific room', permission_classes=[IsAuthenticated], url_name='detail-ai')
    def ai(self, request, *args, **kwargs):
        """start or stop ai participant for a specific room"""
        serializer = serializers.RoomAISerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        room_uuid = self.kwargs.get('uuid')
        queryset = models.Room.objects.filter(uuid__iexact=room_uuid).first()
        if queryset is None:
            raise NotFound("room not found")
        try:
            services.update_ai_for_room(
                room=self.get_object(),
                user=self.request.user,
                **serializer.validated_data,
            )
        except Exception as e:
            data = {'error': 'could not update ai settings for room. Error: {e}'.format(e=e)}
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)
        return Response(data=None, status=status.HTTP_200_OK)


def health_check(request):
    response = JsonResponse({"message": "OK"})
    return response


class AuthViewSet(viewsets.GenericViewSet):

    permission_classes = [AllowAny, ]
    serializer_classes = {
        'register': serializers.RegisterSerializer,
        'login': serializers.LoginSerializer,
        'logout': serializers.EmptySerializer,
        'password_change': serializers.PasswordChangeSerializer,
        'password_reset': serializers.PasswordResetSerializer,
        'password_reset_confirm': serializers.PasswordResetConfirmSerializer,
    }

    @action(methods=['POST', ], detail=False)
    def register(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = services.create_user_account(**serializer.validated_data)
        data = serializers.TokenSerializer(user).data
        return Response(data=data, status=status.HTTP_201_CREATED)

    @action(methods=['POST', ], detail=False)
    def login(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = services.get_and_authenticate_user(**serializer.validated_data)
        data = serializers.TokenSerializer(user).data
        return Response(data=data, status=status.HTTP_200_OK)

    @action(methods=['POST', ], detail=False, permission_classes=[IsAuthenticated])
    def logout(self, request):
        # print(request.__dict__)
        try:
            request.user.auth_token.delete()
        except (AttributeError, ObjectDoesNotExist):
            pass
        logout(request)
        data = {'success': 'successfully logged out'}
        return Response(data=data, status=status.HTTP_200_OK)

    @action(methods=['POST'], detail=False, permission_classes=[IsAuthenticated])
    def password_change(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        request.user.set_password(serializer.validated_data['new_password'])
        request.user.save()
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(methods=['POST', ], detail=False)
    def password_reset(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = services.get_user_by_email(serializer.data['email'])
        if user:
            services.send_password_reset_mail(user)
            data = {'message': 'please follow the instructions in your email'}
        return Response(data=data, status=status.HTTP_200_OK)

    @action(methods=['POST', ], detail=False)
    def password_reset_confirm(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = services.get_user_for_password_reset_token(serializer.validated_data['token'])
        if user:
            user.set_password(serializer.validated_data['new_password'])
            user.save()
        return Response(status=status.HTTP_204_NO_CONTENT)

    def get_serializer_class(self):
        if not isinstance(self.serializer_classes, dict):
            raise ImproperlyConfigured("serializer_classes should be a dict mapping.")

        if self.action in self.serializer_classes.keys():
            return self.serializer_classes[self.action]
        return super().get_serializer_class()


class ParticipantViewSet(
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    viewsets.GenericViewSet):
    """API endpoint that allows websocket participants to be viewed or edited."""
    serializer_class = serializers.ParticipantSerializer
    permission_classes = [IsAuthenticated]
    queryset = models.Participant.objects.all()
    

    lookup_field = 'uuid' # /rooms/{uuid}

    #def get_queryset(self, *args, **kwargs):
    #    return models.Participant.objects.all()

    #def get_object(self):
    #    return models.Participant.objects.first()

    def retrieve(self, request, *args, **kwargs):
        """retrieves details for specific participant"""
        participant_uuid = self.kwargs.get('uuid')
        queryset = models.Participant.objects.filter(uuid__iexact=participant_uuid).first()
        if queryset is None:
            raise NotFound("participant not found")
        extra_context = {'request': self.request, 'user': self.request.user}
        serializer = serializers.ParticipantSerializer(queryset, many=False, context=extra_context)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        try:
            room_uuid = self.kwargs.get('room_uuid')
            services.notify_participants_to_fetch_latest_room_details(
                room_uuid=room_uuid
            )
        except Exception as e:
            data = {'error': 'could not notify participants for room. Error: {e}'.format(e=e)}
            return Response(data=data, status=status.HTTP_400_BAD_REQUEST)
        return response

class UserProfileViewSet(
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    viewsets.GenericViewSet):
    """API endpoint that allows user profiles to be viewed or edited."""
    serializer_class = serializers.UserProfileSerializer
    # queryset = models.UserProfile.objects.all()
    permission_classes = [IsAuthenticated]

    def get_queryset(self, *args, **kwargs):
        user = self.request.user
        return user.profile

    def get_object(self):
        user = self.request.user
        return user.profile

    def list(self, request, *args, **kwargs):
        user = self.request.user
        queryset = models.UserProfile.objects.get(user=user)
        serializer = serializers.ProfileSerializer(queryset, many=False)
        return Response(serializer.data)

    def patch(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

class UserViewSet(mixins.ListModelMixin,
                mixins.RetrieveModelMixin,
                viewsets.GenericViewSet):
    """API endpoint that allows users to be viewed or edited."""
    queryset = get_user_model().objects.all()
    serializer_class = serializers.UserSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        """lists all users"""
        user = self.request.user
        if not user.is_staff:
            return Response(status=status.HTTP_403_FORBIDDEN)
        queryset = get_user_model().objects.all().order_by('id')

        # get query params
        order_by = self.request.query_params.get('order_by', None)
        if order_by is not None:
            queryset = queryset.order_by(order_by)

        # queryset = models.Room.objects.filter(creator=user)
        queryset_page = self.paginate_queryset(queryset)
        if queryset_page is not None:
            serializer = serializers.UserSerializer(queryset_page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = serializers.UserSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, *args, **kwargs):
        """retrieve user details"""
        instance = None
        user_pk = self.kwargs.get('pk', None)
        if user_pk == 'current':
            instance = self.request.user
        else:
            instance = self.get_object()       
        if not self.request.user.is_staff and instance.pk != self.request.user.pk:
            return Response(status=status.HTTP_403_FORBIDDEN)
        serializer = serializers.UserSerializer(instance, many=False, context={'request': request})
        return Response(serializer.data)


class GroupViewSet(viewsets.ModelViewSet):
    """API endpoint that allows groups to be viewed or edited."""
    queryset = Group.objects.all()
    serializer_class = serializers.GroupSerializer



