# dhc-backend
Dhc django backend application

## Installation

Create and activate your python environment first:
```bash
conda create -n dhc-backend python=3.8
conda activate dhc-backend

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install dependencies.
```bash
pip install -r requirements.txt 
python manage.py migrate
```

Create some default users for dhc (see 1password):
```sh
# create one or more admin users
python manage.py ensure_superuser --email=foo@bar.dot --password=password8CharsMin --group=admin
# ...

# create some ai participants (special users)
python manage.py ensure_superuser --email=foo@bar.dot --password=password8CharsMin --group=ai
# ...

# create some doctors (privileged users)
python manage.py ensure_superuser --email=foo@bar.dot --password=password8CharsMin --group=doctor
# ...
```

Only for development, backend should be started from 'autostart'
```bash
python manage.py runserver 8000
```

## Tests

show urls:
python manage.py show_urls

all:
python manage.py test

specific module :
python manage.py test project.tests.test_room

## Usage

```
/admin/
/docs/
/api/auth/register
/api/auth/login
/api/auth/logout
/api/auth/password_change
/api/auth/password_reset_confirm
/api/users/
```

## Examples

Register:
```bash
curl http://127.0.0.1:8000/api/auth/register \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  --data '{"email":"a@b.de","password":"@@1234qwer"}'
```

Login:
```bash
curl http://127.0.0.1:8000/api/auth/login \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  --data '{"email":"a@b.de","password":"@@1234qwer"}'
```

Logout:
```bash
curl -X POST http://127.0.0.1:8000/api/auth/logout \
  -H 'Authorization: Token 7e49e4b2f5d1e5e642368f5d69f5c606a4743f37'
```

Password Change:
```bash
curl http://127.0.0.1:8000/api/auth/password_change \
  -H 'Authorization: Token 7e49e4b2f5d1e5e642368f5d69f5c606a4743f37' \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  --data '{"current_password":"@@1234qwer","new_password":"@@New1234qwer"}'
```

Password Reset:
```bash
curl http://127.0.0.1:8000/api/auth/password_reset \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  --data '{"email":"a@b.de"}'
```

In project/services.py email backend service needs to be implemented to send code for requested password reset user. Code will be printed into console.

Confirm Password Reset:
```bash
curl http://127.0.0.1:8000/api/auth/password_reset_confirm \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  --data '{"token":"Mw::5hm-1c28c4149cc1d244a688", "new_password": "@@1234qwer"}'
```



## Deployment

In deployment environment:
```bash
export DJANGO_DEBUG=False
export DJANGO_SECRET_KEY='SUPER_DUPER_SECRET_KEY_MIN_50_CARS'
```
