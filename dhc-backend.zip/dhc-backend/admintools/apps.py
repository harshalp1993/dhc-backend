from django.apps import AppConfig


class AdmintoolsConfig(AppConfig):
    name = 'admintools'
