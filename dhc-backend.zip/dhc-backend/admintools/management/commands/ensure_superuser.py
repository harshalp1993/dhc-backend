from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group


class Command(BaseCommand):
    help = "Creates an privileged user non-interactively if it doesn't exist"

    def add_arguments(self, parser):
        parser.add_argument('--email', help="User's email")
        parser.add_argument('--password', help="User's password")
        parser.add_argument('--group', help="Group to add user to")

    def handle(self, *args, **options):
        User = get_user_model()
        if not User.objects.filter(email=options['email']).exists():
            user = User.objects.create_superuser(email=options['email'],
                                          password=options['password'])
            if len(options['group']) > 0:
                group, created = Group.objects.get_or_create(name=options['group'])
                user.groups.add(group)
