"""
ASGI config for server project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.2/howto/deployment/asgi/
"""

# order matters, must be set first
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')

# then call django setup
import django
django.setup()

from channels.routing import ProtocolTypeRouter
from django.core.asgi import get_asgi_application
from project.websockets import get_websocket_application


application = ProtocolTypeRouter(
  {
  "http": get_asgi_application(),
  "websocket": get_websocket_application(),
})